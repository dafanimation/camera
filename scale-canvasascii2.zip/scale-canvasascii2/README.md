# Scale canvasAscii2

A Pen created on CodePen.io. Original URL: [https://codepen.io/David-Labiano-Boutens/pen/mdYVeQg](https://codepen.io/David-Labiano-Boutens/pen/mdYVeQg).

